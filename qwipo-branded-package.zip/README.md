Qwipo Branded Prototype - Full Package
======================================

This package contains a full-stack prototype tailored to Qwipo branding:

- qwipo-backend: Node + Express API, MongoDB models, DB seed script
- qwipo-frontend: Vite + React frontend with plain CSS theme matching Qwipo
- recommender: FastAPI microservice (item-based CF) for recommendations
- docker-compose.yml to run everything with Docker
- Instructions for manual & docker runs

See detailed run instructions below and in each subfolder.
